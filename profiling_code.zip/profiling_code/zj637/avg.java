import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class avg {
    public static void main(String[] args) throws Exception { if (args.length != 2) {
        System.err.println("Usage: CountLines <input path> <output path>");
        System.exit(-1);
    }
        Job job = new Job(); job.setJarByClass(avg.class); job.setJobName("Count All Lines");
        FileInputFormat.addInputPath(job, new Path(args[0])); FileOutputFormat.setOutputPath(job, new Path(args[1]));
        job.setMapperClass(avgMapper.class);
        job.setReducerClass(avgReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        job.setNumReduceTasks(1);
        System.exit(job.waitForCompletion(true) ? 0 : 1); }
}

class avgMapper
        extends Mapper<LongWritable, Text, Text, DoubleWritable> {

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String[] input = line.split(",");
        Double income = Double.parseDouble(input[input.length-2]);
        context.write(new Text("average for this numerical column is :"),new DoubleWritable(income));


    }
}
class avgReducer
        extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
    @Override
    public void reduce(Text key, Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException {
        Double sum = 0.0;
        int count = 0;
        for (DoubleWritable value : values) {
            count += 1;
            sum += value.get();
        }
        context.write(key, new DoubleWritable(sum/count)); }
}
